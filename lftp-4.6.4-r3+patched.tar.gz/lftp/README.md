LFTP
===
Command line driven, shell-like, reliable file transfer program. It supports a number of protocols and even BitTorrent with DHT! IPv6 is fully supported too.

[![Flattr this git repo](http://api.flattr.com/button/flattr-badge-large.png)](https://flattr.com/submit/auto?user_id=lavv17&url=https://github.com/lavv17/lftp&title=LFTP+-+sophisticated+file+transfer+program&language=en_GB&tags=github&category=software)
